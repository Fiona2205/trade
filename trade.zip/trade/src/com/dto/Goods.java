package com.dto;

import com.enums.SecurityCodeEnums;

public class Goods {

	private SecurityCodeEnums securityCode;
	
	public SecurityCodeEnums getSecurityCode() {
		return securityCode;
	}

	public void setSecurityCode(SecurityCodeEnums securityCode) {
		this.securityCode = securityCode;
	}

	private int quantity;

	

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
