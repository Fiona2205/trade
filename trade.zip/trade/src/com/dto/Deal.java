package com.dto;

import com.enums.HandleEnums;
import com.enums.OperationEnums;
import com.enums.SecurityCodeEnums;

public class Deal {

	private int tradeId;
	
	private int version;
	
	private SecurityCodeEnums securityCode;
	
	private int quantity;
	
	private HandleEnums handleType;
	
	private OperationEnums operation;

	public int getTradeId() {
		return tradeId;
	}

	public void setTradeId(int tradeId) {
		this.tradeId = tradeId;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public SecurityCodeEnums getSecurityCode() {
		return securityCode;
	}

	public void setSecurityCode(SecurityCodeEnums securityCode) {
		this.securityCode = securityCode;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public HandleEnums getHandle() {
		return handleType;
	}

	public void setHandle(HandleEnums handle) {
		this.handleType = handle;
	}

	public OperationEnums getOperation() {
		return operation;
	}

	public void setOperation(OperationEnums operation) {
		this.operation = operation;
	}
	

}
