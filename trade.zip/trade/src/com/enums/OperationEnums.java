package com.enums;

public enum OperationEnums {
	BUY,SELL;
}
