package com.enums;

public enum SecurityCodeEnums {
	REL,ITC,INF;
}
