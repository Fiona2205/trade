package com.enums;

public enum HandleEnums {
	INSERT,UPDATE,CANCEL;
}
