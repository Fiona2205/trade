import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dto.Deal;
import com.dto.Goods;
import com.enums.HandleEnums;
import com.enums.OperationEnums;
import com.enums.SecurityCodeEnums;
import com.service.TradeService;

public class Trade {

	public static void main(String args[]) {
		
		HashMap<Integer,Deal> map = new HashMap();
		
		TradeService tradeService = new TradeService(); 
		//������������
		/*
		 * Deal addDeal = new Deal(); addDeal.setTradeId(1); addDeal.setVersion(1);
		 * addDeal.setSecurityCode(SecurityCodeEnums.REL); addDeal.setQuantity(50);
		 * addDeal.setHandle(HandleEnums.INSERT);
		 * addDeal.setOperation(OperationEnums.BUY);
		 * 
		 * 
		 * tradeService.trade(addDeal,map); 
		 * System.out.println(map);
		 */
		//���������汾���쳣����
		/*
		 * Deal addDeal = new Deal(); addDeal.setTradeId(1); addDeal.setVersion(2);
		 * addDeal.setSecurityCode(SecurityCodeEnums.REL); addDeal.setQuantity(50);
		 * addDeal.setHandle(HandleEnums.INSERT);
		 * addDeal.setOperation(OperationEnums.BUY);
		 * 
		 * tradeService.trade(addDeal, map); System.out.println(map);
		 */
		//���Ը��½���
		/*
		 * Deal addDeal = new Deal(); addDeal.setTradeId(1); addDeal.setVersion(1);
		 * addDeal.setSecurityCode(SecurityCodeEnums.REL); addDeal.setQuantity(50);
		 * addDeal.setHandle(HandleEnums.INSERT);
		 * addDeal.setOperation(OperationEnums.BUY); tradeService.trade(addDeal,map);
		 * Deal updateDeal = new Deal(); updateDeal.setTradeId(1);
		 * updateDeal.setVersion(2); updateDeal.setSecurityCode(SecurityCodeEnums.REL);
		 * updateDeal.setQuantity(60); updateDeal.setHandle(HandleEnums.UPDATE);
		 * updateDeal.setOperation(OperationEnums.BUY);
		 * tradeService.trade(updateDeal,map); System.out.println(map);
		 */
		//���Ը��½��׽��װ汾��δ����
		/*
		 * Deal addDeal = new Deal(); addDeal.setTradeId(1); addDeal.setVersion(1);
		 * addDeal.setSecurityCode(SecurityCodeEnums.REL); addDeal.setQuantity(50);
		 * addDeal.setHandle(HandleEnums.INSERT);
		 * addDeal.setOperation(OperationEnums.BUY); tradeService.trade(addDeal,map);
		 * Deal updateDeal = new Deal(); updateDeal.setTradeId(1);
		 * updateDeal.setVersion(1); updateDeal.setSecurityCode(SecurityCodeEnums.REL);
		 * updateDeal.setQuantity(60); updateDeal.setHandle(HandleEnums.UPDATE);
		 * updateDeal.setOperation(OperationEnums.BUY);
		 * tradeService.trade(updateDeal,map); System.out.println(map);
		 */
		//���Ը��½��׽��׸���code||quantity||buy/sell
		/*
		 * Deal addDeal = new Deal(); addDeal.setTradeId(1); addDeal.setVersion(1);
		 * addDeal.setSecurityCode(SecurityCodeEnums.REL); addDeal.setQuantity(50);
		 * addDeal.setHandle(HandleEnums.INSERT);
		 * addDeal.setOperation(OperationEnums.BUY); tradeService.trade(addDeal,map);
		 * Deal updateDeal = new Deal(); updateDeal.setTradeId(1);
		 * updateDeal.setVersion(1); updateDeal.setSecurityCode(SecurityCodeEnums.ITC);
		 * updateDeal.setQuantity(60); updateDeal.setHandle(HandleEnums.UPDATE);
		 * updateDeal.setOperation(OperationEnums.SELL);
		 * tradeService.trade(updateDeal,map); System.out.println(map);
		 */
		 
			//���Գ���
		/*
		 * Deal addDeal = new Deal(); addDeal.setTradeId(1); addDeal.setVersion(1);
		 * addDeal.setSecurityCode(SecurityCodeEnums.REL); addDeal.setQuantity(50);
		 * addDeal.setHandle(HandleEnums.INSERT);
		 * addDeal.setOperation(OperationEnums.BUY); tradeService.trade(addDeal,map);
		 * Deal cancelDeal = new Deal(); cancelDeal.setTradeId(1);
		 * cancelDeal.setVersion(2); cancelDeal.setSecurityCode(SecurityCodeEnums.ITC);
		 * cancelDeal.setQuantity(60); cancelDeal.setHandle(HandleEnums.CANCEL);
		 * cancelDeal.setOperation(OperationEnums.SELL);
		 * tradeService.trade(cancelDeal,map); System.out.println(map);
		 */
		 
			//���԰汾��һ�»����ǰһ�汾��
		/*
		 * Deal addDeal = new Deal(); addDeal.setTradeId(1); addDeal.setVersion(1);
		 * addDeal.setSecurityCode(SecurityCodeEnums.REL); addDeal.setQuantity(50);
		 * addDeal.setHandle(HandleEnums.INSERT);
		 * addDeal.setOperation(OperationEnums.BUY); tradeService.trade(addDeal,map);
		 * Deal cancelDeal = new Deal(); cancelDeal.setTradeId(1);
		 * cancelDeal.setVersion(1); cancelDeal.setSecurityCode(SecurityCodeEnums.ITC);
		 * cancelDeal.setQuantity(60); cancelDeal.setHandle(HandleEnums.CANCEL);
		 * cancelDeal.setOperation(OperationEnums.SELL);
		 * tradeService.trade(cancelDeal,map); System.out.println(map);
		 */
		//����ֱ�ӳ���
		/*
		 * Deal cancelDeal = new Deal(); cancelDeal.setTradeId(1);
		 * cancelDeal.setVersion(2); cancelDeal.setSecurityCode(SecurityCodeEnums.ITC);
		 * cancelDeal.setQuantity(60); cancelDeal.setHandle(HandleEnums.CANCEL);
		 * cancelDeal.setOperation(OperationEnums.SELL);
		 * tradeService.trade(cancelDeal,map); System.out.println(map);
		 */
		Map<SecurityCodeEnums,List<Deal>> maps = new HashMap();
		for(HashMap.Entry<Integer,Deal> entry:map.entrySet()){
			if(maps.containsKey(entry.getValue().getSecurityCode())) {
				List<Deal> deals = maps.get(entry.getValue().getSecurityCode());
				deals.add(entry.getValue());
				maps.put(entry.getValue().getSecurityCode(),deals);

			}else {
				List<Deal> list = new ArrayList<>();
				list.add(entry.getValue());
				maps.put(entry.getValue().getSecurityCode(),list);
			}
        }
		
		
		tradeService.calucate(maps);
	
		 
		 
		
	}
}
